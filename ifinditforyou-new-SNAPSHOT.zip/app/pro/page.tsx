import ProPageClient from "./ProPageClient";

export default function ProPage() {
  return <ProPageClient />;
}


