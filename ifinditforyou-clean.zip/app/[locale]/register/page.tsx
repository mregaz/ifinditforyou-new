import RegisterPageClient from "@/components/RegisterPageClient";

export default function Page() {
  return <RegisterPageClient />;
}
