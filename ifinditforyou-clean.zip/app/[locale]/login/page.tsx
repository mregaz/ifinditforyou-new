import LoginPageClient from "@/components/LoginPageClient";

export default function Page() {
  return <LoginPageClient />;
}
