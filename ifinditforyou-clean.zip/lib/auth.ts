import { createClient } from "@/lib/supabase/server";

export async function getCurrentUser() {
  const supabase = await createClient(); // ✅ AWAIT

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return null;
  }

  return user;
}

