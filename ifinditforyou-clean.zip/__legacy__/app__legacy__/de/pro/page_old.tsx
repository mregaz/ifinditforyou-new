import ProPageClient from "@/app/pro/ProPageClient_old";

export default function ProPageDe() {
  return <ProPageClient lang="de" />;
}
