import ProPageClient from "@/app/pro/ProPageClient_old";

export default function ProPageFr() {
  return <ProPageClient lang="fr" />;
}
