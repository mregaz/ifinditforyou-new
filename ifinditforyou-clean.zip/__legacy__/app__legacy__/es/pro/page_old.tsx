// app/es/pro/page.tsx
import ProPageClient from "@/app/pro/ProPageClient_old";

export default function ProPageEs() {
  return <ProPageClient lang="es" />;
}
