import ProPageClient from "@/app/pro/ProPageClient_old";

export default function ProPageIt() {
  return <ProPageClient lang="it" />;
}
