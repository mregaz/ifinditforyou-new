# ifinditforyou-new

Minimal Next.js app (App Router). No PPR, no OpenTelemetry.
Deploy on Vercel with:
- Build Command: `next build`
- Output Directory: `.next`
- Root Directory: (leave empty)
